package gr.forth.ics.graph.metrics;

import gr.forth.ics.graph.Edge;

/**
 * 
 * @author Andreou Dimitris, email: jim.andreou (at) gmail (dot) com
 */
public interface EdgeMetric extends Metric<Edge> {
}
