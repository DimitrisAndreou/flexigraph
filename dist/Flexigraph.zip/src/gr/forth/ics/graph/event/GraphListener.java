package gr.forth.ics.graph.event;

public interface GraphListener extends NodeListener, EdgeListener {
}
