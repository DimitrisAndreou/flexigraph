package gr.forth.ics.graph.path;

/**
 *
 * @deprecated Use {@link Traverser}
 * @author Andreou Dimitris, email: jim.andreou (at) gmail.com
 */
public interface PathAccumulator {
    void addPath(Path path);
}
