package gr.forth.ics.util;

public interface Copyable<T> {
    T copy();
}
